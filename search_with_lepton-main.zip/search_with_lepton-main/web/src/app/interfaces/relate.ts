export interface Relate {
  question: string;
}
